package com.example.pixabayapp.utils

import com.example.pixabayapp.BuildConfig

object Constants {

    const val BASE_URL = "https://pixabay.com/api/"

    const val API_KEY = BuildConfig.API_KEY


}